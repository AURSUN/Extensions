// UrsWiFiSerial
//
// Autor: http://UllisRoboterSeite.de
// Doku:  http://bienonline.magix.net/public/esp8266-wifiserial.html


#include <UrsWiFiSerial.h>

// Constructor
UrsWiFiSerial::UrsWiFiSerial(const uint16_t bufferSize) {
  _BufferSize = bufferSize;
  _Buffer = new uint8_t[_BufferSize];
}

uint8_t UrsWiFiSerial::begin(const IPAddress ip, const uint16_t port) {
  if (!_Buffer)
      return 0; // Fehler, kein Puffer angelegt

  _WiFiClient.stop();
  return (uint8_t) _WiFiClient.connect(ip, port);
}

uint8_t UrsWiFiSerial::begin(const char * host, const uint16_t port) {
  if (!_Buffer) { // noch kein Puffer angelegt
    _Buffer = new uint8_t[_BufferSize];
    if (!_Buffer)
      return 0; // Fehler, kein Puffer angelegt
  }

  _WiFiClient.stop();
  return (uint8_t)_WiFiClient.connect(host, port);
}

uint8_t UrsWiFiSerial::begin(const String host, const uint16_t port) {
  begin(host.c_str(), port);
}



size_t UrsWiFiSerial::write(uint8_t data) {
  _Buffer[_BytesToSend++] = data; // Zeichen in den Puffer stellen

  if ((data == '\n' && XmitOnLf) || (_BytesToSend == _BufferSize))
    xmit();
  if (_WiFiClient.connected())
    return 1;
  else
    return 0;
}

size_t UrsWiFiSerial::write(const uint8_t * buf, size_t size) {
  for (size_t i = 0; i < size; i++)
    write(buf[i]);

  if (_WiFiClient.connected())
    return size;
  else
    return 0;
}

size_t UrsWiFiSerial::xmit(const uint8_t * buf, const size_t size) {
  size_t BytesSent = 0;

  if (_BytesToSend > 0) {
    _WiFiClient.write((const uint8_t *)_Buffer, _BytesToSend);
    _BytesToSend = 0;
  }

  if (buf)
    BytesSent = _WiFiClient.write(buf, size);

  return BytesSent;
}
