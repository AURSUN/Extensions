// UrsWiFiSerial
//
// Autor: http://UllisRoboterSeite.de
// Doku:  http://bienonline.magix.net/public/esp8266-wifiserial.html
// Created: 2017-01-18
//
// Version 1.0 (2017-01-18)
// - Basis-Version

#ifndef _URSWIFISERIAL_h
#define _URSWIFISERIAL_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

#include <ESP8266WiFi.h>

class UrsWiFiSerial : public Stream {
private:
  WiFiClient  _WiFiClient;   // WiFiClient-Instanz zum Senden un Empfangen

protected:
    size_t _BytesToSend;  // Anzahl Bytes, die zur �bertragung anstehen
    uint16_t _BufferSize; // Gr��e des internen Zeichen-Puffers
    uint8_t * _Buffer;    // interner Zeichen-Puffer

public:
   // Constructor: Initialisiert eine neue Instanz der UrsUdpSerial-Klasse
   // bufferSize: Gr��e des internen Zeichen-Puffers
   UrsWiFiSerial(const uint16_t bufferSize = 32);

   // Destructor
   ~UrsWiFiSerial() { delete _Buffer; }

   // Startet den TCP-Client
   // ip: IP des TCP-Servers, mit der Daten ausgetauscht werden sollen
   // port: zug. Port
   uint8_t begin(const IPAddress ip, uint16_t port);

   // Startet den UDP-Client
   // s.o.
   // remoteHost: Name des Host, mit dem Daten ausgetauscht werden sollen.
   // Bei dieser Variante wird Unicast-Betrieb angenommen.
   // Liefert 1, wenn erfolgreich, 0 bei Fehler.
   uint8_t begin(const char *host, const uint16_t port);
   uint8_t begin(const String host, const uint16_t port);

   void stop() { _WiFiClient.stop(); } // Trennt die Verbindung

   size_t NumberOfBytesToSend() { return _BytesToSend; } // Anzahl Bytes, die sich im Zeichen-Puffer befinden
   bool XmitOnLf = true; // true: '\n' l�st �bertragung aus
   IPAddress remoteIP() { return _WiFiClient.remoteIP(); }  // Ruft die IP-Adresse der Remote-Verbindung ab.
   uint16_t remotePort() { return _WiFiClient.remotePort(); } // Ruft den Port der Remote-Verbindung ab.
   bool connected() { return _WiFiClient.connected(); } // Gibt an, ob der Client verbunden ist oder nicht.
                                                       // Achtung: Ein Client gilt als verbunden, 
                                                       // wenn die Verbindung geschlossen wurde, 
                                                       // aber es noch ungelesene Daten gibt.

   virtual size_t xmit(const uint8_t *buf = NULL, const size_t size = 0); // Sendet den Zeichenpuffer und �bertr�gt
                                                                    // anschlie�end den �bergebenen Block.

  // -----------------------------------------------------------------------------
  // �berladene Print:: Funktionen
  virtual size_t write(uint8_t);  // Schreibt einzelnes Byte in den Zeichenpuffer.
  virtual size_t write(const uint8_t *buf, size_t size); // Schreibt einen Block in den Zeichenpuffer.
  
  // �berladene Stream:: Funktionen
  virtual int available() { return _WiFiClient.available(); } // Anzahl der zur Verf�gung stehenden Bytes
  virtual int read() { return _WiFiClient.read(); }           // Ein einzelnes Byte lesen
  virtual int peek() { return _WiFiClient.read(); }           // Das n�chste zu lesende Byte inspizieren
  virtual void flush() { _WiFiClient.flush(); }               // L�scht s�mtliche noch nicht ausgelesene Bytes
};

#endif

