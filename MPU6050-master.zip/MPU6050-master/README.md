MPU6050
=======

Arduino Library for MPU6050 accelerometer module.

Sources taken from http://playground.arduino.cc/Main/MPU-6050
