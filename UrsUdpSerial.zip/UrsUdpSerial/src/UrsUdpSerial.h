// UrsUdpSerial
//
// Autor: http://UllisRoboterSeite.de
// Doku:  http://bienonline.magix.net/public/esp8266-udpserial.html
// Created: 2017-05-26
//
// Version 1.0 (2017-05-26)
// - Basis-Version
//
// Version 1.1 (2017-07-08)
// - Nach jedem Senden (endpacket()) ein delay(1) eingef�gt. Es gab Probleme, wenn
//   direkt hintereinander viele Zeilen ausgegeben wurden.
//
// Version 1.2 (2017-11-06)
// - Viele Schreibfehler ("UPD" statt "UDP") korrigiert.
//
// Version 1.3 (2018-01-11)
// - Wenn das UDP-Paket nicht versandt werden kann, blieb der Pufferinhalt erhalten.
//   Dieser wurde dann beim n�chsten Versand mit versendet.
//   Ab dieser Version wird der Puffer bei jedem Sendeversuch gel�scht.
//
// Version 1.4 (2018-01-29)
// - Methode remoteIP() -> getRemoteIP()
// - Methode remotePort() -> getRemotePort()
// - Neue Option: Betrieb ohne Empfangsfunktion, z.B. f�r Logging
// -              Betrieb ohne Sendefunktion


#ifndef _URSUDPSERIAL_h
#define _URSUDPSERIAL_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

#include <ESP8266WiFi.h>
#include <WiFiUdp.h>

class UrsUdpSerial : public Stream {
private:
  WiFiUDP  _UdpClient;   // UDPClient-Instanz zum Senden un Empfangen

protected:
   uint16_t _BytesToSend;     // Anzahl Bytes, die zur �bertragung anstehen
   uint16_t _BufferSize;      // Gr��e des internen Zeichen-Puffers
   uint8_t *_Buffer = NULL;   // interner Zeichen-Puffer
   bool     _Multicast;       // true, wenn Multicast, sonst false
   IPAddress _RemoteIP;       // IP, an die die Datagramme gesendet werden sollen
   uint16_t _RemotePort;      // zug. Port
   uint16_t _SubscriberPort;  // Lokaler Port, auf dem empfangen werden soll
   uint16_t _TTL = 1;         // Time To Live = Anzahl erlaubter Hops(nur bei Multicast relevant)
   bool     _isListening = false; // true, wenn die Server-Funktion aktiv ist.
 
 public:
   // Constructor: Initialisiert eine neue Instanz der UrsUdpSerial-Klasse
   // bufferSize: Gr��e des internen Zeichen-Puffers
   UrsUdpSerial(const uint16_t bufferSize = 32);

   // Destructor
   ~UrsUdpSerial() { delete _Buffer; }

   // Konfiguriert die Instanz und startet den UDP-Client
   // remoteIP: IP, an die die Datagramme gesendet werden sollen
   // remotePort: zug. Port. Wenn nicht gesendet werden soll: auf 0 setzen.
   // subscriberPort: Lokaler Port, auf dem empfangen werden soll. Wenn kein Empfang vorgesehen ist: auf 0 setzen.
   // ttl: Time To Live = Anzahl erlaubter Hops (nur bei Multicast relevant)
   // Bei Adressen (remoteIP) zwischen 224.0.0.0 und 239.255.255.255 wird Multicast angenommen.
   // remoteIP ist dann die Gruppen-IP. Es wird an die Gruppe gesendet und von ihr empfangen.
   // Liefert 1, wenn erfolgreich, 0 bei Fehler.
   uint8_t begin(const IPAddress remoteIP, const uint16_t remotePort, const uint16_t subscriberPort = 0, const uint16_t ttl = 1);

   // Startet den UDP-Client
   // s.o.
   // remoteHost: Name des Host, mit dem Daten ausgetauscht werden sollen.
   // Bei dieser Variante wird Unicast-Betrieb angenommen.
   uint8_t begin(const char* remoteHost, const uint16_t remotePort, const uint16_t subscriberPort = 0, const uint16_t ttl = 1);
   uint8_t begin(const String remoteHost, const uint16_t remotePort, const uint16_t subscriberPort = 0, const uint16_t ttl = 1);

   void stop() { _UdpClient.stop(); _isListening = false; } // Trennt die Verbindung

   uint16_t numberOfBytesToSend() { return _BytesToSend; } // Anzahl Bytes, die sich im Zeichen-Puffer befinden
   bool isMulticast() { return _Multicast; } // Gibt an, ob Multicast-Betrieb vorliegt.

   IPAddress getRemoteIP() { return _UdpClient.remoteIP(); }  // Ruft die IP-Adresse der Remote-Verbindung ab.
   uint16_t getRemotePort() { return _UdpClient.remotePort(); } // Ruft den Port der Remote-Verbindung ab.

   bool xmitOnLf = true; // true: '\n' l�st �bertragung aus

   // liefert 1 bei Erfolg, 0 bei Fehler
   virtual uint8_t xmit(const uint8_t *buf = NULL, const size_t size = 0); // Sendet den Zeichenpuffer und �bertr�gt
                                                                           // anschlie�end den �bergebenen Block.

   // -----------------------------------------------------------------------------
   // �berladene Print:: Funktionen
   virtual size_t write(uint8_t);  // Schreibt einzelnes Byte in den Zeichenpuffer.
   virtual size_t write(const uint8_t *buf, size_t size); // Schreibt einen Block in den Zeichenpuffer.
 
   // �berladene Stream:: Funktionen
   virtual int available(); // Anzahl der (im aktuellen Paket) verbleibenden Bytes
                            // Pakete werden automatisch nachgeladen
   virtual int read();      // Liest ein einzelnes Byte
   virtual int peek();      // Das n�chste zu lesende Byte inspizieren
   virtual void flush();	  // Beendet das Lesen des aktuellen Pakets
};
#endif

