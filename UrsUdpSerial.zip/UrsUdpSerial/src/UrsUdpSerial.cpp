// UrsUdpSerial
//
// Autor: http://UllisRoboterSeite.de
// Doku:  http://bienonline.magix.net/public/esp8266-Udpserial.html

#include "UrsUdpSerial.h"

// Constructor
UrsUdpSerial::UrsUdpSerial(const uint16_t bufferSize){
  _BufferSize = bufferSize;
  _Buffer = new uint8_t[_BufferSize];
}

uint8_t UrsUdpSerial::begin(const IPAddress remoteIP, const uint16_t remotePort, const uint16_t subscriberPort, const uint16_t ttl) {
  if (!_Buffer)
    return 0; // Fehler, kein Puffer angelegt

  _UdpClient.stop();
  _isListening = false;

  _RemoteIP = remoteIP;
  _RemotePort = remotePort;
  _SubscriberPort = subscriberPort;
  _TTL = ttl;

  // Server starten
  if (subscriberPort) {
    // Mulitcast-Adresse?
    if (_RemoteIP[0] >= 224 && _RemoteIP[0] <= 239) {
      _Multicast = true;
      uint8_t result = _UdpClient.beginMulticast(WiFi.localIP(), _RemoteIP, _SubscriberPort);
      if (result)
        _isListening = true;
      return result;
    }

    // Unicast
    uint8_t result = _UdpClient.begin(_SubscriberPort);
    if (result)
      _isListening = true;
    return result;
  } // if subscriberPort

  return 1; // kein Server
}

uint8_t UrsUdpSerial::begin(const char * remoteHost, const uint16_t remotePort, const uint16_t subscriberPort, const uint16_t ttl){
  IPAddress remote_addr;
  if (!WiFi.hostByName(remoteHost, remote_addr)) // hostByName: 1 bei Erfolg, sonst 0
    return 0;

  return begin(remote_addr, remotePort, subscriberPort, ttl);
}

uint8_t UrsUdpSerial::begin(const String remoteHost, const uint16_t remotePort, const uint16_t subscriberPort, const uint16_t ttl) {
  begin(remoteHost.c_str(), remotePort, subscriberPort, ttl);
}

// Print::write
size_t UrsUdpSerial::write(uint8_t data) {
  if (_Buffer) {
    _Buffer[_BytesToSend++] = data; // Zeichen in den Puffer stellen

    if ((data == '\n' && xmitOnLf) || (_BytesToSend == _BufferSize)) // Zeilenende oder Puffer voll?
      xmit();

    return 1;
  }

  return 0;
}

// Print::write
size_t UrsUdpSerial::write(const uint8_t * buf, const size_t size) {
  for (size_t i = 0; i < size; i++)
    write(buf[i]);

  return size;
}

// Daten senden
// Liefert 1 bei Erfolg, 0 bei Fehler
uint8_t UrsUdpSerial::xmit(const uint8_t * buf, const size_t size) {
  if(!_RemotePort)
    goto ErrorExit;

  if (_BytesToSend > 0) { // zuerst den Zeichen-Puffer senden
    if (_Multicast) { // zwischen Unicast und Multicast unterscheiden
      if (!_UdpClient.beginPacketMulticast(_RemoteIP, _RemotePort, WiFi.localIP(), _TTL)) // Multicast
        goto ErrorExit;
    }
    else {
      if (!_UdpClient.beginPacket(_RemoteIP, _RemotePort)) // Unicast
        goto ErrorExit;
    }

    _UdpClient.write(_Buffer, _BytesToSend);

    if (!_UdpClient.endPacket())
      goto ErrorExit;

    delay(1);
    _BytesToSend = 0;
  }

  if (buf) { // dann die �bergebenen Daten
    if (_Multicast) {
      if (!_UdpClient.beginPacketMulticast(_RemoteIP, _RemotePort, WiFi.localIP(), _TTL)) // Multicast
        return 0;
    }
    else {
      if (!_UdpClient.beginPacket(_RemoteIP, _RemotePort)) // Unicast
        return 0;
    }

    _UdpClient.write(buf, size);

    if (!_UdpClient.endPacket())
      return 0;
    delay(1);
  }
  return 1;

ErrorExit:
  _BytesToSend = 0;
  return 0;
}

// Stream::available
int UrsUdpSerial::available() {
  int cnt;
  if (cnt = _UdpClient.available())
    return cnt;

  // Wenn das aktuelle Paket ausgelesen ist, mit dem n�chsten Paket weitermachen
  return _UdpClient.parsePacket();
}

// Stream::read
int UrsUdpSerial::read() {
  if (!_UdpClient.available()) // Wenn das aktuelle Paket ausgelesen ist, mit dem n�chsten Paket weitermachen
    _UdpClient.parsePacket();
  return _UdpClient.read();
}


int UrsUdpSerial::peek() {
  if (!_UdpClient.available()) // Wenn das aktuelle Paket ausgelesen ist, mit dem n�chsten Paket weitermachen
    _UdpClient.parsePacket();
  return _UdpClient.peek();
}

void UrsUdpSerial::flush() {
  _UdpClient.flush();
}
